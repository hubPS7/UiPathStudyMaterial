# Calculate-Client-Security-Hash
UiPath Level 3 - Advanced Training, Exercise 2
